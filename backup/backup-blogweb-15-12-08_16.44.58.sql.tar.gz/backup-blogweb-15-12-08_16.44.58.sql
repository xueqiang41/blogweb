-- MySQL dump 10.13  Distrib 5.5.46, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: blogweb
-- ------------------------------------------------------
-- Server version	5.5.46-0ubuntu0.14.04.2
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogs` (
  `id` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_image` varchar(500) NOT NULL,
  `name` varchar(50) NOT NULL,
  `summary` varchar(200) NOT NULL,
  `content` mediumtext NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` VALUES ('001449485017255002e93c21087433eae6493794f4ce181000','001449294006006f00c820575854873a77e03ff55d79308000','88','http://www.gravatar.com/avatar/7c68aac96ec01d863887a7c77a6cd987?d=mm&s=120','SpaceX推出第二代太空船','SpaceX在美国太平洋时间29日晚上7点，推出了可在地球与国际空间站之间来回穿梭运送宇航员的最新太空船Dragon V2。','据《连线》网站报道，伊隆·马斯克（Elon Musk）旗下的宇航公司SpaceX在美国太平洋时间29日晚上7点，推出了可在地球与国际空间站之间来回穿梭运送宇航员的最新太空船Dragon V2（第二代）。马斯克还拥有生产电动汽车的特斯拉公司。\n\nDragon V2是Dragon太空船的改进版，后者从2012年10月起进行了3次向国际空间站运送物质的无人飞行任务，最后一次在本月初返回了地面。美国宇航局（NASA）希望新的太空船能在2017或2018年实现载人飞行。今年早些时候，美国宣布太空站计划延长至2024年。\n\n但2011年美国就终止了航天飞机计划，将宇航员送到国际空间站的唯一方法是搭载俄罗斯的联盟号飞船。昨天联盟号飞船刚将包括美国宇航员雷德·威丝曼（Reid Wiseman）在内的乘员送入太空，美国为此支付了7000多万美元费用。\n\n最近，由于美国在乌克兰问题上对俄罗斯实施制裁，俄罗斯威胁停止运送美国宇航员进入国际空间站，搭乘联盟号飞船成为不具吸引力的选择。为此，NASA与波音和Sierra Nevada公司也签署合同，希望两家公司与SpaceX一起开发飞船运送宇航员。\n\n不过SpaceX有一个优势，已经基本开发出了带推进器的太空船，可使飞船乘员在火箭出现问题时让飞船与之分离，终止飞行任务。这些被称为SuperDracos的推进器本周进行了点火测试并通过了质量检验。马斯克当日在洛杉矶郊外的SpaceX操作间展示了最新的太空船。他站在旁边摆放着新飞船的舞台上向与会者介绍了其功能，用电脑动画描述飞船如何使用推进器在返回地球表面时进行无降落伞的软着陆。马斯克称：“这是21世纪的太空飞船，可以快速重复使用。”\n\n他表示，新飞船将安装原先飞船发动机的“超能”版，并能与国际空间站对接。与航天飞机一样，新飞船也可搭载7名宇航员，预计2-3年内实现首次载人试飞。与Dragon无人飞船一样，Dragon V2飞船也将通过SpaceX研发的猎鹰9号火箭发射升空。',1449485017.2556);
INSERT INTO `blogs` VALUES ('001449535983366a67f34652b2d4ceda2bc679f0d126c8d000','001449294006006f00c820575854873a77e03ff55d79308000','88','http://www.gravatar.com/avatar/7c68aac96ec01d863887a7c77a6cd987?d=mm&s=120','开源的机器学习Python模块','scikit-learn是一个用于机器学习的Python模块，建立在SciPy基础之上。','scikit-learn是一个用于机器学习的Python模块，建立在SciPy基础之上，获得BSD开源许可证。这个项目是由David Cournapeau在 2007年发起的一个Google Summer of Code项目，从那时起这个项目就已经拥有很多的贡献者了，而且该项目目前为止也是由一个志愿者团队在维护着。\n\n主要特点：\n\n操作简单、高效的数据挖掘和数据分析\n\n无访问限制，在任何情况下可重新使用\n\n建立在NumPy、SciPy 和 matplotlib基础上\n\n使用商业开源协议——BSD许可证\n\n链接：http://scikit-learn.org\n\nscikit-learn 经过测试之后可以运行在 Python 2.6、Python 2.7 和 Python 3.4平台上。除此之外，它还要适应运行在Python 3.3平台上。',1449535983.36679);
INSERT INTO `blogs` VALUES ('001449536031856cb35007b7a8a434fbdc44f715bd4238d000','001449294006006f00c820575854873a77e03ff55d79308000','88','http://www.gravatar.com/avatar/7c68aac96ec01d863887a7c77a6cd987?d=mm&s=120','哈勃拍摄宇宙彩色“全家福”','科学家整合了“哈勃”太空望远镜10年来拍摄的宇宙照片，得到迄今为止最全面、最多彩的宇宙照片，并于6月3日发布，填补了宇宙研究的一项空白。','“哈勃”望远镜10年来拍摄的作品拼接成1张宇宙照片。\n\n科学家整合了“哈勃”太空望远镜10年来拍摄的宇宙照片，得到迄今为止最全面、最多彩的宇宙照片，并于6月3日发布，填补了宇宙研究的一项空白。\n\n“哈勃”望远镜于2003至2012年间致力于给宇宙拍照。美国航空航天局(NASA)的科学家把“哈勃”多年的心血整合成了一张“哈勃外深域紫外线图像”。这张图像包含1000多个星系，其中不乏大爆炸后几百万年之内就已经形成的古老星系。\n\n主研究员、加州理工大学的哈利？特普利茨说：“我们这么做是为了研究宇宙的‘少年时代’，当时它还在‘长身体’呢。我们拍摄了紫外线照片，以此观察星系中形成的最年轻、最庞大、温度最高的恒星。\n\n科学家们过去用近红外线研究大爆炸之后不久的早期宇宙，另外对“已经长大”的宇宙也有所了解；但宇宙在这两段时间之间的状况却几乎是一块空白，所以才有了这张拼接照片查漏补缺。\n\n研究成员、亚利桑达州立大学的罗吉尔？温德霍斯特说：“‘哈勃’提供了极其宝贵的紫外线数据库，我们需要把它和红外线数据合并，展现它们联合起来的力量。”',1449536031.85599);
INSERT INTO `blogs` VALUES ('001449536116143e1bfe24857ee4624b174bcf407aacec8000','001449294006006f00c820575854873a77e03ff55d79308000','88','http://www.gravatar.com/avatar/7c68aac96ec01d863887a7c77a6cd987?d=mm&s=120','谷歌推出无人驾驶汽车','这辆萌极了的很像“考拉”的玩意儿，是Google酝酿5年的产品，无人驾驶汽车，终于在5月29号的Code Conference科技大会上面世了。','这辆萌极了的很像“考拉”的玩意儿，是Google酝酿5年的产品，无人驾驶汽车，终于在5月29号的Code Conference科技大会上面世了。\n\n除了萌，这款原型车的最大的特点是无人驾驶。然后，没有后座、后备箱、音响，只有控制汽车行驶和停驻的几个大按钮。看起来，为了减负，Google甚至没有把logo印上去。没有方向盘、刹车、油门，只有软件和传感器负责车辆的“驾驶”。\n\n会不会不安全？“小考拉”的司机--无人驾驶原型车的软件系统已经在丰田普锐斯和雷克萨斯的 SUV 改装车上应用多年，它经过了长达 5 年多的高速公路和城市街道测试。\n\n呃，有一点不知道该不该说，这辆车的最高时速只有40公里/小时。Google 无人驾驶项目负责人克里斯·厄姆森（Chris Urmson）说了，40公里/小时的最高速度在多数情况下不会超出时速限制。',1449536116.14308);
INSERT INTO `blogs` VALUES ('0014495361684864d0d10b0dba4434ba8130ee7d7ce01c2000','001449294006006f00c820575854873a77e03ff55d79308000','88','http://www.gravatar.com/avatar/7c68aac96ec01d863887a7c77a6cd987?d=mm&s=120','苹果公司发布新一代移动操作系统iOS 8','苹果公司在美国旧金山召开2014年度全球开发者大会。苹果公司发布了最新一代移动操作系统iOS 8，对短信、输入法、通知中心、搜索等多款应用的功能进行了大幅升级。iOS 8正式版将在今年秋天发布，支持iPhone 4s及以后的设备。','苹果公司在美国旧金山召开2014年度全球开发者大会。苹果公司发布了最新一代移动操作系统iOS 8，对短信、输入法、通知中心、搜索等多款应用的功能进行了大幅升级。iOS 8正式版将在今年秋天发布，支持iPhone 4s及以后的设备。\n\n最新一代移动操作系统iOS 8与上一代iOS 7的界面基本相同，但是对一些常用功能进行了大幅改进。\n\n首先，iOS 8系统中的顶部通知栏增强了互动性。以短信应用为例，用户在收到一条短信时，可以直接在通知栏里进行回复，而不用再进入短信应用界面。其他应用也是类似。\n\n由于短信功能是最为常用的功能，在最新的移动系统中，苹果公司花了许多力气改进iOS 8的短信功能。用户可以使用短信分享地址，输入语音短信，还能发送语音和视频，利用iMessage发起群聊等。\n\n在iOS 7中，用户通过双击Home键进入多任务管理后台，在iOS 8中，苹果公司对多任务后台进行了功能上的丰富，在任务栏上方加入了最近联系人，可以快捷地进行通话、发送短信等。\n\n输入功能也获得了智能提升。在最新的iOS 8中，苹果开放了第三方输入法，但为了安全在某些界面有所限制，另外系统会在用户输入时给予“预测性建议”。比如，朋友发短信问你今晚一起吃饭还是看电影？QuickType功能就会在输入法中显示“吃饭”或“看电影”，让你完成快捷回复。\n\n新iOS系统的搜索功能也很强大。iOS 8系统中的Spotlight不再只是本地搜索，可以联网找App，找新闻、餐厅、歌曲、电影等。\n\niOS 8系统还首次支持用户打包购买APP应用，通常用户可以借此获得一定的折扣。\n\niOS 8新系统中还增加了健康管理功能HealthKit。HealthKit是一个可穿戴设备的管理软件，支持耐克等可穿戴产品。HealthKit已经有许多合作伙伴，他们将为之开发能够适配的软硬件产品。\n\n新iOS 8系统还新增了家庭分享(Family Sharing)功能。用户在iTunes购买一首歌，就可以利用这个功能分享给最多6个家庭成员，非常实用省钱。\n\n照片功能也有大幅改进。用户可以对图片进行“智能编辑”，调整图片的多个参数，比如曝光度、对比度、亮度等。\n\n此外，语音助手Siri也进行了升级，增加支持中国农历等功能。\n\n苹果公司表示，iOS 8系统将在今天推出开发者测试版，而正式版会在今年秋天发布，支持iPhone 4s及以后的设备。',1449536168.48658);
INSERT INTO `blogs` VALUES ('0014495362302847fd41087145a4a448579da33779977e5000','001449294006006f00c820575854873a77e03ff55d79308000','88','http://www.gravatar.com/avatar/7c68aac96ec01d863887a7c77a6cd987?d=mm&s=120','Python 3.5将支持Async/Await异步编程','Python 3.5将通过async和await语法增加对协程的支持。该提案目的是使协程成为Python语言的原生特性，并“建立一种普遍、易用的异步编程思维模型。”','根据Python PEP 0492，Python 3.5将通过async和await语法增加对协程的支持。该提案目的是使协程成为Python语言的原生特性，并“建立一种普遍、易用的异步编程思维模型。”\n\n这个新提议中声明一个协程的语法如下：\n\nasync def read_data(db): pass\n\nasync是明确将函数声明为协程的关键字，即便没有使用await表达式。这样的函数执行时会返回一个协程对象。\n\n在协程函数内部，可在某个表达式之前使用await关键字来暂停协程的执行，以等待某进程完成。\n\n由于增强版生成器的存在，Python中其实早已有了协程的形式，例如当yield或yield from声明在Python生成器内部出现，该生成器就会被当作协程。\n\n每当生成器在for循环中被调用，该生成器中的for循环就会返回一个新的值。\n\n关于await用法的更多示例请参见上文提到的PEP 0492。\n\n这个关于协程的新提案想明确地把生成器与协程区分开，这么做有如下好处：\n\n使这两个概念对新开发者来说更易于理解，因为它们二者的语法并不一样； 能消除由于重构时不小心移除了协程中的yield声明而导致的“不明确错误”，这会导致协程变成普通的生成器。 async/await语法能让程序员以序列方式编写代码，但编译器则会将其当作一系列的协程来处理，从而实现有效的并发。回到我们之前的例子，async/await使我们可以顺序地编写多个await声明语句，就好像每个语句都会阻塞并等待结果，但实际上这并不会导致任何阻塞',1449536230.28466);
INSERT INTO `blogs` VALUES ('001449545956286555816db0a5c4e62a16401221f2f1a98000','001449545692830d886f50ef543417bb20895ec608a4d56000','99','http://www.gravatar.com/avatar/36e17f1e5a05a354d4e0e729c215e1d2?d=mm&s=120','11','2222','33333',1449545956.28602);

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` varchar(50) NOT NULL,
  `blog_id` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_image` varchar(500) NOT NULL,
  `content` mediumtext NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--


--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `passwd` varchar(50) NOT NULL,
  `admin` tinyint(1) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(500) NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_email` (`email`),
  KEY `idx_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES ('00144904441158762fe61783f3d4988b0b161663409ebca000','about:blank','1234567890',0,'Test','test@example.com',1449044411.58742);
INSERT INTO `users` VALUES ('001449045101439866d30211daa45ffbbd27e2bf02f395e000','test@example.com','1234567890',0,'Test','about:blank',1449045101.43903);
INSERT INTO `users` VALUES ('001449249597699966ab696e70f4c2abc548a9c070115b0000','11@163.com','927f015775472936f7e03da3834718465c57e128',0,'11','http://www.gravatar.com/avatar/e35fb5a5e5b79ce7c0f38a9bf6d3c3a1?d=mm&s=120',1449249597.69967);
INSERT INTO `users` VALUES ('001449252491576e19a4780d33c4648b4ac9e2171dc2e7f000','22@163.com','6d98331a71dbd61b3d185147559bb219e4f6622f',0,'22','http://www.gravatar.com/avatar/7bf71d6698d665048341459c1364209f?d=mm&s=120',1449252491.57715);
INSERT INTO `users` VALUES ('00144925257106285ef9b0c21624eb8b4cb299ae3a1ee96000','33@163.com','1c715693efe94a0fd6a02aafe50cde1047c12482',0,'33','http://www.gravatar.com/avatar/9dcdfddd9a217ff463474d401e325402?d=mm&s=120',1449252571.06313);
INSERT INTO `users` VALUES ('0014492526234412f6b90ab3e204bbdb1abea11a16ee408000','44@163.com','03081d38e271941dcee3c9df2e3dee3e35dd6fa0',0,'44','http://www.gravatar.com/avatar/045e1796ce44ea73fc0c7f355b013acf?d=mm&s=120',1449252623.44185);
INSERT INTO `users` VALUES ('0014492527415185534971796a042fdb6cbada177c8faa2000','55@163.com','eb48f26d270086632802f602ca242a00b7acc122',0,'55','http://www.gravatar.com/avatar/a9edc779659f9dd7c08afa151aa855be?d=mm&s=120',1449252741.51833);
INSERT INTO `users` VALUES ('001449293202072ca9c1bb6973c4a4fa35f34328bdecd23000','66@163.com','40ef61792f93ab64dc363f2b8f764aeea985e6e1',0,'66','http://www.gravatar.com/avatar/95c9837c8e71f8ca631109302c3b25c8?d=mm&s=120',1449293202.07264);
INSERT INTO `users` VALUES ('0014492933569617ae22b3ba99a4819b5c541e3aeb1c37a000','77@163.com','70cf928249828c77b346c3ee3e74e8863b4c6818',0,'77','http://www.gravatar.com/avatar/257302443106aced0a623cbd0077ffce?d=mm&s=120',1449293356.96206);
INSERT INTO `users` VALUES ('001449294006006f00c820575854873a77e03ff55d79308000','88@163.com','25d3c05ff7899bc5d7ed60f1640e61d6b69f4305',1,'88','http://www.gravatar.com/avatar/7c68aac96ec01d863887a7c77a6cd987?d=mm&s=120',1449294006.00699);
INSERT INTO `users` VALUES ('001449545692830d886f50ef543417bb20895ec608a4d56000','99@163.com','b34312fff2527475da18bdb04060ce50fceb56fc',0,'99','http://www.gravatar.com/avatar/36e17f1e5a05a354d4e0e729c215e1d2?d=mm&s=120',1449545692.83076);
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-12-08 16:45:02
